//
//  FinalProjectAppApp.swift
//  FinalProjectApp
//
//  Created by Jacob Bishop on 9/13/24.
//

import SwiftUI

@main
struct FinalProjectAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
