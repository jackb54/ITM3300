//
//  Settings Functionality.swift
//  Final Project-1
//
//  Created by Ryan Speulstra on 9/13/24.
//

import SwiftUI

struct SettingsView: View {
    @State private var option1Enabled = false
    @State private var option2Enabled = true
    @State private var privacyText = UserDefaults.standard.string(forKey: "privacyText") ?? ""
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("General")) {
                    Toggle(isOn: $option1Enabled) {
                        Text("Enable National Notifications")
                    }
                    
                    Toggle(isOn: $option2Enabled) {
                        Text("Dark Mode")
                    }
                }
                
                Section(header: Text("Set Default Location")) {
                    TextField("Enter ZIP", text: $privacyText)
                        .onChange(of: privacyText) { oldValue, newValue in
                            savePrivacyText(newValue)
                        }
                }
            }
            .navigationTitle("Settings")
            .listStyle(InsetGroupedListStyle())
            .backgroundStyle(Color(red: 0.1529, green: 0.1686, blue: 0.4982))
        }
    }
    
    // Function to save the privacy text input locally using UserDefaults. This was generated using ChatGPT.
    func savePrivacyText(_ text: String) {
        UserDefaults.standard.set(text, forKey: "privacyText")
    }
}

#Preview {
    SettingsView()
}
