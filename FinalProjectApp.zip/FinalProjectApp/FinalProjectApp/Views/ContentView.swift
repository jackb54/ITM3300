//
//  ContentView.swift
//  FinalProjectApp
//
//  Created by Jacob Bishop on 9/13/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        MainView(numWidgets: 6)
    }
}

struct MainView: View {
    @State var numWidgets: Int
    let backgroundColor: Color = Color(red: 0.1529, green: 0.1686, blue: 0.4902)
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 0)
                .fill(backgroundColor)
            VStack {
                buttons
                temp
                Spacer()
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                    ForEach(0..<numWidgets, id:\.self) {index in
                        Widget(symbol: "☀️")
                    }
                }
                Spacer()
//                HStack {
//                    VStack{
//                        Widget(symbol: "☀️")
//                        Widget(symbol: "🍃")
//                        Widget(symbol: "☀️")
//                    }
//                    VStack{
//                        Widget(symbol: "🌧️")
//                        Widget(symbol: "☀️")
//                        Widget(symbol: "☀️")
//                    }
//                }
            }
            .padding()
        }
    }
    var temp: some View {
        Text("75°")
            .foregroundStyle(.white)
            .font(.system(size: 85))
            .bold()
    }
    
    var buttons: some View {
        HStack {
            Button(action: {print("options")}, label: {
                Image(systemName: "gearshape")
                    .foregroundStyle(.white)
                    .font(.largeTitle)
            })
            Spacer()
            Button(action: {print("info")}, label: {
                Image(systemName: "info.circle")
                    .foregroundStyle(.white)
                    .font(.title2)
            })
        }
    }
}

struct Widget: View {
    var fillCol: Color = Color(red: 0.1803, green: 0.2039, blue: 0.5804)
    var symbol: String
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25.0)
                .fill(fillCol)
                .strokeBorder(.white, lineWidth: 4)
            Text(symbol)
                .font(.system(size:70))
        }
    }
}

#Preview {
    ContentView()
}
